# Guide: persistent memory for Claude Code

## 1. Why the agent "forgets"
Each Claude Code session starts with a fresh context. It automatically loads `CLAUDE.md` files (project root, parent dirs, and `~/.claude/CLAUDE.md`). Anything not in those files, or imported with `@path`, must be rediscovered. This kit puts the important things where they are loaded every time, and keeps them small so they don't waste tokens.

## 2. The four memory files
- **project.md** – stable facts. Rarely changes.
- **progress.md** – the handoff note between sessions. Changes every session.
- **decisions.md** – append-only log, stops the agent from re-litigating choices.
- **gotchas.md** – failure -> cause -> fix. Prevents repeating the same bug.
Only `project.md` is imported into CLAUDE.md; the others are read on demand (by `/recap` or the hook) to save context.

## 3. Daily workflow
1. After install (or when boot feels heavy): `/bootcheck` once — audit always-on context before you burn tokens on "hi".
2. Start: `/recap` (or rely on the SessionStart hook).
3. Work normally.
4. End: `/remember` (optionally `/remember we switched auth to magic links`).
5. When the thread feels expensive (long history, repeats, summaries of summaries), run `/handover`, open a new session, run `/recap` — do not keep burning tokens on message #200.
6. Commit `memory/` with your code so history travels with the repo.

## 4. Codex CLI and other agents
Codex reads `AGENTS.md`. Keep CLAUDE.md and AGENTS.md aligned, or make one a short pointer to the other.

## 5. What survives /compact (and what doesn't)
Claude Code's `/compact` keeps your root `CLAUDE.md`. Path-scoped rules that live only as loose context often get dropped in the summary, so the agent looks like it "got worse" after a compact. Put rules you cannot afford to lose in:
- root `CLAUDE.md` (or a file it `@`-imports), or
- `memory/*.md` that `/recap` and the SessionStart hook re-read from disk after compact.
Folder-only rules that are never reloaded from disk are the ones that vanish. This kit's memory files are on disk in git on purpose: after `/compact`, run `/recap` (or start a new session) so progress, decisions and gotchas come back from files, not from the thinned chat.

## 6. Hygiene
- Never store secrets; only env var names.
- Prune monthly: summarize old progress into one line per week.
- If a file passes ~150 lines, summarize it.

## 7. When to use something else
- Want automatic capture of every tool call with search? Try the free open-source `claude-mem` (github.com/thedotmack/claude-mem).
- Want only quick notes? Claude Code's built-in `#` shortcut and `/memory` command may be enough.
This kit is for people who want an explicit, reviewable, git-tracked memory with no background service.

## 8. New session when the thread gets expensive
Token burn is often in chat history, not in your code. A long thread with repeats and summaries-of-summaries reloads the same context on every turn. When that happens: run `/handover` (writes a short on-disk state: Next, Blocked, Stopped at, plus any new decisions/gotchas), open a **new** session, then `/recap`. The next session starts cheap because it reads a few Markdown files instead of message #200.

## 9. Boot tax before you say hi
Token burn often starts **before** the first real prompt. Root `CLAUDE.md`, `@`-imports, always-on skills/plugins/MCP can already load tens of thousands of tokens by the time you type "hi". Keep always-loaded CLAUDE.md lean; import only `project.md` (this kit's default). Keep progress, decisions and gotchas on disk and load them on demand with `/recap`. Park unused skills and MCP (tool search / disable until needed). Run `/bootcheck` after install and whenever boot feels heavy.
This is different from §8 (expensive *thread* history → `/handover` + new session) and §5 (`/compact` survival of on-disk memory). Boot tax is what loads every session before work; thread tax is what piles up *during* a long chat.
