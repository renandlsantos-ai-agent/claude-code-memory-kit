# Routing policy (Opus only for the plan)

Burning Opus on file search and reads is a common failure mode: the quota is gone before the hard design work starts.

- On-disk rule: `.claude/rules/model-routing.md` (survives `/compact` and new sessions).
- Refresh or reinstall: `/routeplan`.
- Default tiers: search/read → cheapest capable (Haiku / Fable / equivalent); multi-file grind edits → Sonnet; plan / architecture / hard tradeoffs → Opus only.
- Price the work before burning Opus: prefer a cheap model first when the task is clearly search/read.
- Chat-only "use Haiku for search" tips die on `/compact`; keep the policy in the rule file.
- Honest limit: Claude Code may not expose per-tool model switches in every UI. The rule still guides human/harness model choice and agent recommendations for the next step.

This is separate from path-scoped coding rules (`/pathscope`) and from the shell-allow policy (`/allowcanon`).
