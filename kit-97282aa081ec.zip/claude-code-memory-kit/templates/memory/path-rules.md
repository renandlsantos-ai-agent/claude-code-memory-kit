# Path-scoped rules (on disk)

Rules that apply only to part of the repo (e.g. "frontend uses Tailwind, no inline styles") should live in files, not in chat.

- Location: `.claude/rules/*.md` (one file per area). Claude Code reads these from disk; if your tool does not, `@`-import the file from `CLAUDE.md` or point `AGENTS.md` at it.
- Each file starts with YAML frontmatter listing `paths:` globs the rule applies to. A rule file without `paths:` applies everywhere.
- Keep each file short (5-20 bullets). Concrete beats vague.
- Add or update one with `/pathscope "<glob>" <rule text>`.
- Commit `.claude/rules/` with your code.

Why: a rule you only typed in chat ("in src/api always return typed errors") is usually lost or blurred by `/compact`. A rule file on disk is still there after `/compact` and in every new session.

Example: `.claude/rules/example-frontend.md` (installed from `templates/rules/example-frontend.md`). Rename it or delete it.
