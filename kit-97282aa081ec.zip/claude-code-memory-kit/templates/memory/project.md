# Project
- What it is (1 sentence):
- Users:
- Stack:
- Key directories:
- External services / env vars (names only, never values):
- Definition of done:
