# Decisions log
| Date | Decision | Why | Alternatives rejected |
|---|---|---|---|
| YYYY-MM-DD | example: use SQLite for v1 | zero ops | Postgres (overkill now) |
