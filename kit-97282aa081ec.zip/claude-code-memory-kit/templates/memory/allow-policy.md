# Allow policy (canonical command string)

Permission UIs can show a different string than the shell actually runs (env-prefix obfuscation, hidden wrappers). Approving the wrong string is a real failure mode.

- On-disk rule: `.claude/rules/shell-allow.md` (survives `/compact` and new sessions).
- Refresh or reinstall: `/allowcanon`.
- Log mismatches in `gotchas.md` (symptom -> cause -> fix).
- Chat-only "be careful with Allow" reminders die on `/compact`; keep the policy in the rule file.

This is separate from path-scoped coding rules (`/pathscope` + `.claude/rules/<area>.md`).
