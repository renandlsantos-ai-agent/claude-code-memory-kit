---
paths:
  - "frontend/**"
  - "src/components/**"
---
# Frontend rules (example – edit or delete)

- Framework: <fill in, e.g. React 19 + TypeScript strict>
- Styling: <fill in, e.g. Tailwind only, no inline styles>
- Components: <fill in, e.g. one component per file, named exports>
- State/data: <fill in, e.g. server data via the existing query hooks, no new global store>
- Tests: <fill in, e.g. every new component gets a test next to it>
