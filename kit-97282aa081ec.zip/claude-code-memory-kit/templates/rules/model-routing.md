---
# Applies project-wide (no paths: filter). Keep this file short.
---
# Model routing – Opus only for the plan

- File search / read / grep / list → cheapest capable model (Haiku / Fable / equivalent).
- Multi-file grind edits → mid model (Sonnet).
- Plan, architecture, hard design tradeoffs → Opus only.
- Before burning Opus, price the work: prefer a cheap model first when the task is clearly search/read.
- Keep this policy on disk; chat tips die on `/compact`.
- Honest limit: Claude Code may not expose per-tool model switches in every UI. This rule still guides when the human (or harness) chooses a model, and when the agent recommends which model/tier to use for the next step.

## Project-specific
- <add project model overrides here>
