---
# Applies project-wide (no paths: filter). Keep this file short.
---
# Shell allow policy – approve only the canonical string

- Before Allow/Yes on a shell tool call, compare the **exact string shown in the UI** to the **exact string that will run**.
- Approve only when they match character-for-character (the canonical string). If anything differs (env prefix, `VAR=…` obfuscation, hidden newlines, `bash -c` wrapping the UI hid, or a rewritten path), **Deny** and ask the human.
- Never approve a command you cannot read in full in the approval UI.
- Do not invent permissions. Prefer deny / ask over silent allow for destructive or network commands.
- If a mismatch or near-miss happens, append one line to `memory/gotchas.md`: `UI showed X -> shell ran Y -> Denied; require canonical string`.

## Project-specific
- <add project allow/deny notes here>
