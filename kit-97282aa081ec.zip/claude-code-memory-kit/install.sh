#!/usr/bin/env bash
# Usage: run inside your project root. Never overwrites existing files.
set -e
K="$(cd "$(dirname "$0")" && pwd)"
cp_safe(){ if [ -e "$2" ]; then echo "skip (exists): $2"; else mkdir -p "$(dirname "$2")"; cp "$1" "$2"; echo "added: $2"; fi; }
cp_safe "$K/templates/CLAUDE.md" CLAUDE.md
cp_safe "$K/templates/AGENTS.md" AGENTS.md
for m in project decisions progress gotchas; do cp_safe "$K/templates/memory/$m.md" "memory/$m.md"; done
cp_safe "$K/commands/remember.md" .claude/commands/remember.md
cp_safe "$K/commands/recap.md" .claude/commands/recap.md
cp_safe "$K/commands/handover.md" .claude/commands/handover.md
cp_safe "$K/commands/bootcheck.md" .claude/commands/bootcheck.md
cp_safe "$K/commands/pathscope.md" .claude/commands/pathscope.md
cp_safe "$K/commands/allowcanon.md" .claude/commands/allowcanon.md
cp_safe "$K/commands/routeplan.md" .claude/commands/routeplan.md
mkdir -p .claude/rules
cp_safe "$K/templates/rules/example-frontend.md" .claude/rules/example-frontend.md
cp_safe "$K/templates/rules/shell-allow.md" .claude/rules/shell-allow.md
cp_safe "$K/templates/rules/model-routing.md" .claude/rules/model-routing.md
cp_safe "$K/templates/memory/path-rules.md" memory/path-rules.md
cp_safe "$K/templates/memory/allow-policy.md" memory/allow-policy.md
cp_safe "$K/templates/memory/routing-policy.md" memory/routing-policy.md
cp_safe "$K/hooks/session-start.sh" .claude/hooks/session-start.sh
chmod +x .claude/hooks/session-start.sh
cp_safe "$K/hooks/settings.example.json" .claude/settings.json
echo "Done. If .claude/settings.json already existed, merge hooks/settings.example.json by hand."
