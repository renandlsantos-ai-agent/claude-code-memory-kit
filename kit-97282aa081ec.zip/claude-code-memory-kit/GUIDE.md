# Guide: persistent memory for Claude Code

## 1. Why the agent "forgets"
Each Claude Code session starts with a fresh context. It automatically loads `CLAUDE.md` files (project root, parent dirs, and `~/.claude/CLAUDE.md`). Anything not in those files, or imported with `@path`, must be rediscovered. This kit puts the important things where they are loaded every time, and keeps them small so they don't waste tokens.

## 2. The four memory files
- **project.md** – stable facts. Rarely changes.
- **progress.md** – the handoff note between sessions. Changes every session.
- **decisions.md** – append-only log, stops the agent from re-litigating choices.
- **gotchas.md** – failure -> cause -> fix. Prevents repeating the same bug.
Only `project.md` is imported into CLAUDE.md; the others are read on demand (by `/recap` or the hook) to save context.

## 3. Daily workflow
1. Start: `/recap` (or rely on the SessionStart hook).
2. Work normally.
3. End: `/remember` (optionally `/remember we switched auth to magic links`).
4. Commit `memory/` with your code so history travels with the repo.

## 4. Codex CLI and other agents
Codex reads `AGENTS.md`. Keep CLAUDE.md and AGENTS.md aligned, or make one a short pointer to the other.

## 5. Hygiene
- Never store secrets; only env var names.
- Prune monthly: summarize old progress into one line per week.
- If a file passes ~150 lines, summarize it.

## 6. When to use something else
- Want automatic capture of every tool call with search? Try the free open-source `claude-mem` (github.com/thedotmack/claude-mem).
- Want only quick notes? Claude Code's built-in `#` shortcut and `/memory` command may be enough.
This kit is for people who want an explicit, reviewable, git-tracked memory with no background service.
