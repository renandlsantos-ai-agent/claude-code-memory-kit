---
description: Audit always-on boot context before the first real task
---
Audit what this project loads **before** the first real task (boot tax). Do not edit files unless asked. Report:

1. **Always-on load**
   - Root `CLAUDE.md`: line count and approximate size; list every `@`-import.
   - Note whether `memory/progress.md`, `decisions.md`, or `gotchas.md` are imported into CLAUDE.md (they should not be — load them on demand via `/recap`).
   - Skills, plugins, MCP servers, and rules that appear to load every session (list names; mark unknown if you cannot see config).

2. **Keep vs park**
   - **Keep**: needed every session (e.g. lean CLAUDE.md + `@memory/project.md` only).
   - **Park / lazy**: unused skills, MCP, plugins — suggest tool search or disable until needed.

3. **Flags**
   - CLAUDE.md over ~150 lines, or dumping full progress/decisions/gotchas into always-loaded context.
   - Suggest keeping only `project.md` imported in CLAUDE.md (this kit's default).

4. **Checklist + budget**
   Print a short checklist and a suggested boot budget: aim under ~5–8k tokens of always-on **project** context (exact budgets vary by plan; user/system/tool overhead is separate). If boot feels heavy after install or later, re-run `/bootcheck`.
