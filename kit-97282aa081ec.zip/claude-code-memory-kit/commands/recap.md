---
description: Recap project state from memory before starting work
---
Read `CLAUDE.md`, `memory/project.md`, `memory/progress.md`, `memory/gotchas.md` and the last 10 entries of `memory/decisions.md`.
Reply with: 1) what the project is, 2) where we stopped, 3) the next 3 tasks, 4) gotchas relevant to them. Do not edit files.
