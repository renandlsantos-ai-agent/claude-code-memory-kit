---
description: Save a path-scoped rule to .claude/rules/ so it survives /compact
argument-hint: "<glob>" <rule text>
---
Save a path-scoped rule to disk. Input: $ARGUMENTS

1. **Collect input.** If $ARGUMENTS does not contain both a path glob (e.g. `src/api/**`) and the rule text, ask the user for whatever is missing. Ask once, briefly. Do not guess the glob.

2. **Pick the file.** Use `.claude/rules/<area>.md`, where `<area>` is a short kebab-case name derived from the glob (e.g. `src/api/**` -> `api.md`). Create `.claude/rules/` if needed. If a rule file already lists the same glob in its `paths:` frontmatter, update that file instead of creating a new one.

3. **Write it.**
   - New file: start with YAML frontmatter, then a heading, then the rule as a bullet:
     ```
     ---
     paths:
       - "<glob>"
     ---
     # <Area> rules

     - <rule text>
     ```
   - Existing file: keep the frontmatter valid (add the glob to `paths:` only if missing), append the rule as a new bullet, and do not duplicate a bullet that already says the same thing.
   - Keep rules short and concrete. Never write secrets, tokens or keys; if the rule needs one, refer to the env var name only. Do not invent facts about the project.

4. **Confirm.** Show the final file content and its path. Remind the user: rules that exist only in chat usually get dropped or blurred by `/compact`; this file is on disk and will still apply after `/compact` and in new sessions. Suggest committing `.claude/rules/`.
