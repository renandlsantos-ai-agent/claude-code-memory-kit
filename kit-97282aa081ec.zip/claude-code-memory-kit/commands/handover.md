---
description: Write a short handover so the next session starts cheap
---
The current chat is getting expensive or we are about to start a fresh session. Update memory for a clean handoff:
- `memory/progress.md`: rewrite Next (max 5 bullets), Blocked (max 3), and one line "Stopped at:". Move finished work to Done (keep only the latest ~10 Done bullets).
- `memory/decisions.md`: append any decision made this session that is not already logged (date, decision, why).
- `memory/gotchas.md`: append any new failure→fix from this session.
Keep every line short. Never write secrets. Then print a 6-line handover block the human can paste into a new session: project one-liner, stopped at, next 3 tasks, relevant gotchas. Extra note: $ARGUMENTS
