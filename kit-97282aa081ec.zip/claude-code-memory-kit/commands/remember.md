---
description: Save what we just learned into project memory
---
Review this session. Update the memory files:
- `memory/progress.md`: move finished items to Done, refresh Next and Blocked.
- `memory/decisions.md`: append any non-obvious decision with date and reason.
- `memory/gotchas.md`: append surprising failures and fixes.
Keep entries short. Never write secrets. Show me a diff summary when done. Extra note from me: $ARGUMENTS
