---
description: Install or refresh the on-disk model-routing policy (Opus only for plan)
argument-hint: [optional note to append to gotchas]
---
Install or refresh the model-routing policy on disk so it survives `/compact` and new sessions. Input: $ARGUMENTS

1. **Ensure folders.** Create `.claude/rules/` and `memory/` if missing.

2. **Write the rule file** `.claude/rules/model-routing.md` (create or overwrite only the kit-managed sections; keep any user bullets under `## Project-specific`). Content:
   ```
   ---
   # Applies project-wide (no paths: filter). Keep this file short.
   ---
   # Model routing – Opus only for the plan

   - File search / read / grep / list → cheapest capable model (Haiku / Fable / equivalent).
   - Multi-file grind edits → mid model (Sonnet).
   - Plan, architecture, hard design tradeoffs → Opus only.
   - Before burning Opus, price the work: prefer a cheap model first when the task is clearly search/read.
   - Keep this policy on disk; chat tips die on `/compact`.
   - Honest limit: Claude Code may not expose per-tool model switches in every UI. This rule still guides when the human (or harness) chooses a model, and when the agent recommends which model/tier to use for the next step.

   ## Project-specific
   - <add project model overrides here>
   ```

3. **Write the memory note** `memory/routing-policy.md` if missing (do not overwrite if it already exists with user edits):
   - Explain that burning Opus on file search / read is a common failure mode (quota gone before the hard work starts).
   - Point to `.claude/rules/model-routing.md` and `/routeplan` to refresh.
   - Remind: chat-only "use Haiku for search" tips die on `/compact`; this file and the rule file do not.

4. **Optional gotcha.** If $ARGUMENTS is non-empty, append one bullet to `memory/gotchas.md` with that note (symptom -> cause -> fix). Do not invent incidents.

5. **Confirm.** Show paths written. Remind: commit `.claude/rules/model-routing.md` and `memory/routing-policy.md`. This is different from `/allowcanon` (shell approval) and `/pathscope` (path-scoped coding rules) — `/routeplan` is the project-wide model-routing policy.
