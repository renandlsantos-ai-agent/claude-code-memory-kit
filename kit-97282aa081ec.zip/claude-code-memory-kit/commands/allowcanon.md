---
description: Install or refresh the on-disk "approve only canonical command" policy
argument-hint: [optional note to append to gotchas]
---
Install or refresh the shell-allow policy on disk so it survives `/compact` and new sessions. Input: $ARGUMENTS

1. **Ensure folders.** Create `.claude/rules/` and `memory/` if missing.

2. **Write the rule file** `.claude/rules/shell-allow.md` (create or overwrite only the kit-managed sections; keep any user bullets under `## Project-specific`). Content:
   ```
   ---
   # Applies project-wide (no paths: filter). Keep this file short.
   ---
   # Shell allow policy – approve only the canonical string

   - Before Allow/Yes on a shell tool call, compare the **exact string shown in the UI** to the **exact string that will run**.
   - Approve only when they match character-for-character (the canonical string). If anything differs (env prefix, `VAR=…` obfuscation, hidden newlines, `bash -c` wrapping the UI hid, or a rewritten path), **Deny** and ask the human.
   - Never approve a command you cannot read in full in the approval UI.
   - Do not invent permissions. Prefer deny / ask over silent allow for destructive or network commands.
   - If a mismatch or near-miss happens, append one line to `memory/gotchas.md`: `UI showed X -> shell ran Y -> Denied; require canonical string`.

   ## Project-specific
   - <add project allow/deny notes here>
   ```

3. **Write the memory note** `memory/allow-policy.md` if missing (do not overwrite if it already exists with user edits):
   - Explain that Claude Code / Codex permission UIs can show a different string than the shell executes (e.g. env-prefix bypasses fixed in recent Claude Code releases).
   - Point to `.claude/rules/shell-allow.md` and `/allowcanon` to refresh.
   - Remind: chat-only "be careful with allow" rules die on `/compact`; this file and the rule file do not.

4. **Optional gotcha.** If $ARGUMENTS is non-empty, append one bullet to `memory/gotchas.md` with that note (symptom -> cause -> fix). Do not invent incidents.

5. **Confirm.** Show paths written. Remind: commit `.claude/rules/shell-allow.md` and `memory/allow-policy.md`. This is different from `/pathscope` (path-scoped coding rules) — `/allowcanon` is the project-wide shell approval policy.
