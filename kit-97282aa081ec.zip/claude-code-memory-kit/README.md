# Claude Code Project Memory Kit (v1.5)

A ready-to-copy setup so Claude Code (and Codex CLI) stop forgetting your project between sessions.
Plain Markdown files + two small shell hooks. No server, no database, no extra API cost.

## What's inside
- `templates/CLAUDE.md` – root memory file Claude Code loads automatically every session.
- `templates/AGENTS.md` – same idea for Codex CLI and other agents that read AGENTS.md.
- `templates/memory/` – structured memory files: `project.md`, `decisions.md`, `progress.md`, `gotchas.md`.
- `templates/memory/path-rules.md` – how path-scoped rules live on disk in `.claude/rules/*.md` with `paths:` frontmatter.
- `templates/memory/allow-policy.md` – why UI≠shell mismatches matter; points at the on-disk shell-allow rule.
- `templates/rules/example-frontend.md` – example path-scoped rule file (installed to `.claude/rules/`; edit or delete).
- `templates/rules/shell-allow.md` – project-wide policy: approve only the canonical command string.
- `commands/remember.md`, `commands/recap.md`, `commands/handover.md`, `commands/bootcheck.md`, `commands/pathscope.md`, `commands/allowcanon.md` – custom slash commands (`/remember`, `/recap`, `/handover`, `/bootcheck`, `/pathscope`, `/allowcanon`).
- `hooks/session-start.sh` – prints a short recap of progress at session start.
- `hooks/settings.example.json` – how to register the hook in `.claude/settings.json`.
- `install.sh` – copies everything into a project without overwriting existing files.
- `GUIDE.md` – how the system works, daily workflow, and when to use a free tool instead.

## Quick install (2 minutes)
```bash
unzip claude-code-memory-kit.zip
cd your-project
bash /path/to/claude-code-memory-kit/install.sh
```
Then open Claude Code and run `/bootcheck` once, then `/recap`. Optionally run `/allowcanon` to refresh the shell-allow policy.

## Why files on disk
Root `CLAUDE.md` survives `/compact`; path-scoped rules that only lived in chat often do not. `/pathscope "src/api/**" always return typed errors` writes the rule to `.claude/rules/api.md` with `paths:` frontmatter. v1.5 adds the same discipline for shell approvals: `/allowcanon` installs `.claude/rules/shell-allow.md` so you only Allow when the UI string matches the shell string character-for-character (env-prefix / obfuscation mismatches get Denied and logged to `gotchas.md`). This kit keeps progress, decisions and gotchas in `memory/` so `/recap` can reload them after a compact. When a thread gets expensive (long history, repeats), run `/handover`, open a new session, and `/recap` — token burn is often in history, not code. Boot hygiene: keep always-loaded CLAUDE.md lean (only `@memory/project.md`) so typing "hi" does not burn 30k+ tokens of project context before real work; run `/bootcheck` after install or when boot feels heavy.

## Honest note
Free alternatives exist and are good: the open-source `claude-mem` project, Claude Code's built-in `#` memory shortcut and `/memory` command, and free guides on Gumroad. This kit's value is a tested, opinionated file structure, commands and a guide, ready in minutes. If you prefer automatic capture with a background service, try claude-mem.

License: personal and commercial use in your own projects. Please don't resell the kit itself.
