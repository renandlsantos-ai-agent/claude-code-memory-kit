#!/usr/bin/env bash
# Prints recent progress so it lands in Claude Code's context at session start.
f="${CLAUDE_PROJECT_DIR:-.}/memory/progress.md"
[ -f "$f" ] && { echo "== memory/progress.md =="; head -n 40 "$f"; }
exit 0
