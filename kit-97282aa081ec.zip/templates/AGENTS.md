# Agent instructions and project memory (AGENTS.md)

## Always
- At session start, read `memory/progress.md` and `memory/gotchas.md` before touching code.
- Before ending a task, update `memory/progress.md` (done / next / blocked) in 3-6 bullets.
- When we make a non-obvious choice, append it to `memory/decisions.md` (date, decision, why, alternatives).
- When something breaks in a surprising way, add it to `memory/gotchas.md`.
- Keep each memory file under ~150 lines; summarize older entries instead of deleting meaning.
- Path-scoped rules (apply only to some folders) belong on disk in `.claude/rules/*.md` with `paths:` frontmatter, not only in chat. Before editing files, read any `.claude/rules/*.md` whose `paths:` globs match them. In Claude Code, save new ones with `/pathscope "<glob>" <rule>`; chat-only rules die on `/compact`, these files do not.

## Project facts
See `memory/project.md`.

## Commands
- Install: `<fill in>`
- Test: `<fill in>`
- Run: `<fill in>`

## Style
- <fill in: language, formatter, naming conventions>
