# Project memory (read me first)

## Always
- At session start, read `memory/progress.md` and `memory/gotchas.md` before touching code.
- Before ending a task, update `memory/progress.md` (done / next / blocked) in 3-6 bullets.
- When we make a non-obvious choice, append it to `memory/decisions.md` (date, decision, why, alternatives).
- When something breaks in a surprising way, add it to `memory/gotchas.md`.
- Keep each memory file under ~150 lines; summarize older entries instead of deleting meaning.
- After `/compact` or a long session, re-read `memory/progress.md` and `memory/gotchas.md` from disk (path-scoped chat rules may have been dropped; these files were not).
- Before starting a fresh session after a long or expensive thread, run `/handover` so the next session loads a short on-disk state instead of burning tokens on chat history.
- Path-scoped rules (apply only to some folders) belong on disk in `.claude/rules/*.md` with `paths:` frontmatter, not only in chat. Save new ones with `/pathscope "<glob>" <rule>`; chat-only rules die on `/compact`, these files do not.

## Project facts
@memory/project.md

## Commands
- Install: `<fill in>`
- Test: `<fill in>`
- Run: `<fill in>`
- Memory: `/recap` (start), `/remember` (end), `/handover` (before a fresh session after a long/expensive thread), `/bootcheck` (after install / when boot feels heavy), `/pathscope` (save a path-scoped rule to `.claude/rules/`)

## Style
- <fill in: language, formatter, naming conventions>
